from collections import defaultdict
from .names import clean


def choose_canonical(records):
    """Choose the best source row to represent the current person fields.

    This does not discard the other records; their provenance is aggregated
    into AppearsIn, CodeHistory, InclusionBasisHistory, SourceCount, etc.
    """
    def score(r):
        return (
            10 if clean(r.get("PrimaryEmail")) else 0,
            5 if clean(r.get("Institution")) else 0,
            3 if r.get("SourceFile") != "contacts.csv" else 0,
            2 if clean(r.get("DisplayName")) else 0,
            -int(str(r.get("SourceRow") or 999999)),
        )
    return max(records, key=score)


def group_records(rows):
    groups = []
    used = set()

    # Exact email match is strongest.
    by_email = defaultdict(list)
    for i, r in enumerate(rows):
        if r.get("EmailKey"):
            by_email[r["EmailKey"]].append(i)
    for key, idxs in by_email.items():
        if len(idxs) > 1:
            group = sorted(set(idxs))
            groups.append(("exact_email", 100, group))
            used.update(group)

    # Exact normalized name + institution.
    by_name_inst = defaultdict(list)
    for i, r in enumerate(rows):
        key = (r.get("NameKey"), r.get("InstitutionKey"))
        if key[0] and key[1] and i not in used:
            by_name_inst[key].append(i)
    for key, idxs in by_name_inst.items():
        if len(idxs) > 1:
            group = sorted(set(idxs))
            groups.append(("exact_name_institution", 96, group))
            used.update(group)

    # Possible duplicates: exact normalized name only.
    possible = []
    by_name = defaultdict(list)
    for i, r in enumerate(rows):
        if r.get("NameKey"):
            by_name[r["NameKey"]].append(i)
    for key, idxs in by_name.items():
        if len(idxs) > 1:
            possible.append(("exact_name_only", 82, sorted(set(idxs))))

    return groups, possible


def _unique_join(records, field):
    return "; ".join(sorted({clean(r.get(field, "")) for r in records if clean(r.get(field, ""))}))


def _record_confidence(records, merge_reason=None, merge_confidence=None):
    """Estimate confidence that a master row belongs in the SAGP database.

    This is intentionally separate from merge confidence.  A singleton from a
    SAGP source file can be high-confidence even though no merge occurred.
    """
    source_files = {clean(r.get("SourceFile")) for r in records if clean(r.get("SourceFile"))}
    bases = " ".join(clean(r.get("InclusionBasis")) for r in records).lower()
    has_non_contacts = any(src and src != "contacts.csv" for src in source_files)
    has_contacts = "contacts.csv" in source_files

    if len(records) > 1:
        if merge_reason == "exact_email":
            return 100
        if merge_reason == "exact_name_institution":
            return 97 if len(source_files) > 1 else 96
        return max(90, int(merge_confidence or 90))

    if has_non_contacts:
        return 95
    if "mentions sagp" in bases:
        return 85
    if "matches sagp source" in bases:
        return 90
    if has_contacts:
        return 75
    return 70


def _review_status(source_count, merge_reason, record_confidence):
    if source_count == 1:
        return "AUTO_SINGLE"
    if merge_reason in {"exact_email", "exact_name_institution"}:
        return "AUTO_MERGED"
    if record_confidence < 85:
        return "REVIEW_LOW_CONFIDENCE"
    return "AUTO"


def _apply_master_metadata(canonical, records, *, merge_reason, merge_confidence):
    source_count = len(records)
    source_files = {clean(r.get("SourceFile")) for r in records if clean(r.get("SourceFile"))}
    canonical["SourceCount"] = source_count
    canonical["UniqueSourceCount"] = len(source_files)
    canonical["MergedRecordCount"] = source_count  # retained for backward compatibility
    canonical["MergeConfidence"] = "" if source_count == 1 else merge_confidence
    canonical["MergeReason"] = merge_reason if source_count > 1 else "single_record"
    canonical["AppearsIn"] = _unique_join(records, "SourceFile")
    canonical["CodeHistory"] = _unique_join(records, "OriginalMembershipCode")
    canonical["InclusionBasisHistory"] = _unique_join(records, "InclusionBasis")
    canonical["RecordConfidence"] = _record_confidence(records, merge_reason, merge_confidence)
    canonical["ReviewStatus"] = _review_status(source_count, merge_reason, canonical["RecordConfidence"])
    return canonical


def build_master(rows):
    auto_groups, possible_groups = group_records(rows)
    assigned = {}
    master = []
    merge_log = []

    for group_num, (reason, confidence, idxs) in enumerate(auto_groups, start=1):
        pid = f"SAGP{len(master)+1:06d}"
        recs = [rows[i] for i in idxs]
        canonical = dict(choose_canonical(recs))
        canonical["PersonID"] = pid
        _apply_master_metadata(canonical, recs, merge_reason=reason, merge_confidence=confidence)
        master.append(canonical)
        for r in recs:
            assigned[r["RawRecordID"]] = pid
            merge_log.append({
                "PersonID": pid,
                "RawRecordID": r["RawRecordID"],
                "Reason": reason,
                "Confidence": confidence,
                "SourceFile": r.get("SourceFile"),
                "SourceRow": r.get("SourceRow"),
            })

    for r in rows:
        if r["RawRecordID"] not in assigned:
            pid = f"SAGP{len(master)+1:06d}"
            canonical = dict(r)
            canonical["PersonID"] = pid
            _apply_master_metadata(canonical, [r], merge_reason="single_record", merge_confidence="")
            master.append(canonical)
            assigned[r["RawRecordID"]] = pid

    # Map PersonID to master row so review status can be updated after possible
    # duplicate groups are generated.
    master_by_pid = {r["PersonID"]: r for r in master}

    duplicate_review = []
    seen = set()
    review_group = 1
    for reason, confidence, idxs in possible_groups:
        raw_ids = tuple(sorted(rows[i]["RawRecordID"] for i in idxs))
        if raw_ids in seen:
            continue
        seen.add(raw_ids)
        pids = {assigned.get(rid) for rid in raw_ids}
        if len(pids) == 1:
            continue
        for pid in pids:
            if pid in master_by_pid and master_by_pid[pid].get("ReviewStatus") != "AUTO_MERGED":
                master_by_pid[pid]["ReviewStatus"] = "REVIEW_POSSIBLE_DUPLICATE"
        for i in idxs:
            r = dict(rows[i])
            r["ReviewGroup"] = f"REVIEW{review_group:04d}"
            r["SuggestedReason"] = reason
            r["SuggestedConfidence"] = confidence
            r["CurrentPersonID"] = assigned.get(r["RawRecordID"], "")
            duplicate_review.append(r)
        review_group += 1

    return master, duplicate_review, merge_log
